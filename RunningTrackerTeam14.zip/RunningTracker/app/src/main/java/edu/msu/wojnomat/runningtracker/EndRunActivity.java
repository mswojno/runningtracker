package edu.msu.wojnomat.runningtracker;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * This demo shows how GMS Location can be used to check for changes to the users location.  The
 * "My Location" button uses GMS Location to set the blue dot representing the users location.
 * Permission for {@link android.Manifest.permission#ACCESS_FINE_LOCATION} is requested at run
 * time. If the permission has not been granted, the Activity is finished with an error message.
 */
public class EndRunActivity extends AppCompatActivity
        implements
        OnMyLocationButtonClickListener,
        OnMyLocationClickListener,
        OnMapReadyCallback,
        ActivityCompat.OnRequestPermissionsResultCallback {

    /**
     * Request code for location permission request.
     *
     * @see #onRequestPermissionsResult(int, String[], int[])
     */
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    /**
     * Flag indicating whether a requested permission has been denied after returning in
     * {@link #onRequestPermissionsResult(int, String[], int[])}.
     */
    private boolean mPermissionDenied = false;

    private GoogleMap mMap;
    private ActiveListener activeListener = new ActiveListener();
    private LocationManager locationManager = null;
    private Location currentLocation = null;

    private ArrayList<Double> latDoubles = new ArrayList<>();
    private ArrayList<Double> longDoubles = new ArrayList<>();

    private int mTotalCal = 0;
    private String mTotalDistance = "";
    private String mTime = "";
    private String mAvgPace = "";
    private int mTotalRuns = 0;
    private String mCal;
    private String mMinutes;
    private String mSeconds;
    private String mSteps;

    private TextView mTotalDistanceValue;
    private TextView mAveragePaceValue;
    private TextView mTimeValue;
    private TextView mCalValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_run);

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ViewGroup.LayoutParams params = mapFragment.getView().getLayoutParams();

        ArrayList<String> latStrings = getIntent().getStringArrayListExtra("latLocations");
        ArrayList<String> longStrings = getIntent().getStringArrayListExtra("longLocations");

        mTotalDistanceValue = findViewById(R.id.totalDistanceValue);
        mTotalDistance = getIntent().getStringExtra("dist");
        mTotalDistanceValue.setText(mTotalDistance);

        mAveragePaceValue = findViewById(R.id.paceValue);
        mAvgPace = getIntent().getStringExtra("pace");
        if (mAvgPace.equals("")){
            mAvgPace = "00:00";
        }
        mAveragePaceValue.setText(mAvgPace);

        mTimeValue = findViewById(R.id.timeValue);
        mTime = getIntent().getStringExtra("time");
        if (mTime == null){
            mTime = "00:00";
        }
        mTimeValue.setText(mTime);

        mCalValue = findViewById(R.id.caloriesValue);
        mCal = getIntent().getStringExtra("cals");
        mCalValue.setText(mCal);

        latDoubles = convertStringListToDouble(latStrings);
        longDoubles = convertStringListToDouble(longStrings);

        int width = getScreenWidth();

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {

            if ((width > 480 || width == 480) && width < 1080) {
                //Nexus 4
                //Nexus 7
                params.height = 300;

            } else if ((width > 1080 || width == 1080) && width < 1200) {
                //Nexus 5
                params.height = 750;


            } else if ((width > 1200 || width == 1200)) {
                //Nexus 7
                params.height = 750;
            }
        }

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if ((width > 800 || width == 800) && width < 1794) {
                //Nexus 4

            } else if ((width > 1794 || width == 1794) && width < 1920) {
                //Nexus 5

            } else if ((width > 1920 || width == 1920)) {
                //Nexus 7
            }
        }

        mapFragment.getView().setLayoutParams(params);

        // Get the location manager
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // Create a Criteria object
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_HIGH);
        criteria.setAltitudeRequired(true);
        criteria.setBearingRequired(false);
        criteria.setSpeedRequired(false);
        criteria.setCostAllowed(false);

        String bestAvailable = locationManager.getBestProvider(criteria, true);

        if (bestAvailable != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            locationManager.requestLocationUpdates(bestAvailable, 500, 1, activeListener);
            currentLocation = locationManager.getLastKnownLocation(bestAvailable);

        }


    }

    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;
        // Add polylines and polygons to the map. This section shows just
        // a single polyline. Read the rest of the tutorial to learn more.

        PolylineOptions pp = new PolylineOptions().clickable(true);

        for (int i = 0; i < longDoubles.size(); i++){
            pp.add(new LatLng(latDoubles.get(i), longDoubles.get(i)));
        }

        Polyline polyline1 = mMap.addPolyline(pp);

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latDoubles.get(latDoubles.size()/2), longDoubles.get(longDoubles.size()/2)), 13));
    }

    /**
     * Handle start of run
     *
     * @param view Button view
     */
    public void onReturn(View view) {
        // End the game and transition to end game activity
        Intent intent = new Intent(this, MapsActivity.class);
        intent.putExtra("dist", mTotalDistance);
        if (!mTime.equals("00:00") || Double.parseDouble(mTotalDistance) != 0.0){
            mTotalRuns++;
        }
        intent.putExtra("totalRuns", Integer.toString(mTotalRuns));
        intent.putExtra("cals", mCal);
        intent.putExtra("pace", mAvgPace);
        mMinutes = getIntent().getStringExtra("minutes");
        mSeconds = getIntent().getStringExtra("seconds");
        intent.putExtra("min", mMinutes);
        intent.putExtra("sec", mSeconds);
        startActivity(intent);
    }

    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else if (mMap != null) {
            // Access to the location has been granted to the app.
            mMap.setMyLocationEnabled(true);
        }
    }

    @Override
    public boolean onMyLocationButtonClick() {
        Toast.makeText(this, "MyLocation button clicked", Toast.LENGTH_SHORT).show();
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).
        return false;
    }

    @Override
    public void onMyLocationClick(@NonNull Location location) {
        Toast.makeText(this, "Current location:\n" + location, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode != LOCATION_PERMISSION_REQUEST_CODE) {
            return;
        }

        if (PermissionUtils.isPermissionGranted(permissions, grantResults,
                Manifest.permission.ACCESS_FINE_LOCATION)) {
            // Enable the my location layer if the permission has been granted.
            enableMyLocation();
        } else {
            // Display the missing permission error dialog when the fragments resume.
            mPermissionDenied = true;
        }
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        if (mPermissionDenied) {
            // Permission was not granted, display error dialog.
            showMissingPermissionError();
            mPermissionDenied = false;
        }
    }

    /**
     * Displays a dialog with error message explaining that the location permission is missing.
     */
    private void showMissingPermissionError() {
        PermissionUtils.PermissionDeniedDialog
                .newInstance(true).show(getSupportFragmentManager(), "dialog");
    }

    private void setMargins(View view, int left, int top, int right, int bottom) {
        if (view.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams p = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            p.setMargins(left, top, right, bottom);
            view.requestLayout();
        }
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    private class ActiveListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {

        }

        @Override
        public void onStatusChanged(String s, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    }

    ;

    private void registerListeners() {
        unregisterListeners();
    }

    private void unregisterListeners() {
        locationManager.removeUpdates(activeListener);
    }

    /**
     * Called when this application is no longer the foreground application.
     */
    @Override
    protected void onPause() {
        unregisterListeners();
        super.onPause();
    }

    /**
     * Called when this application becomes foreground again.
     */
    @Override
    protected void onResume() {
        super.onResume();
        registerListeners();
    }

    public ArrayList<Double> convertStringListToDouble(ArrayList<String> s){
        ArrayList<Double> d = new ArrayList<>();

        for (int i = 0; i < s.size(); i++){
            d.add(Double.parseDouble(s.get(i)));
        }

        return d;
    }

}
