package edu.msu.wojnomat.runningtracker;

// Will listen to step alerts
public interface StepListener {

    public void step(long timeNs);

}
