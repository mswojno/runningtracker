package edu.msu.wojnomat.runningtracker;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RunningActivity extends AppCompatActivity {

    Chronometer cmTimer;
    Button btnStart, btnStop, btnReset;
    Boolean resume = false;
    long elapsedTime;
    double mTotaldistance = 0.0;
    String mPace = "00:00";
    int mCals = 0;
    String TAG = "TAG";
    LatLng startingLocation;
    ArrayList<String> latLocations =new ArrayList<>();
    ArrayList<String> longLocations = new ArrayList<>();
    ArrayList<Double> distance_per_second =new ArrayList<>();
    ArrayList<Double> avgPaceValues = new ArrayList<>();
    private RunningActivity.ActiveListener activeListener = new RunningActivity.ActiveListener();
    private LocationManager locationManager = null;
    float[] distance_n = new float[1];
    final double WEIGHT = 59;
    TextView distanceView;
    TextView curpaceView;
    TextView calView;
    TextView runValues;
    Location start;
    private String time;
    private long mMinutes;
    private long mSeconds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_running);

        Double locLat = Double.parseDouble(getIntent().getStringExtra("starting_location_latitude"));
        Double locLong = Double.parseDouble(getIntent().getStringExtra("starting_location_longitude"));
        startingLocation = new LatLng(locLat, locLong);
        start = new Location("");
        start.setLongitude(startingLocation.longitude);
        start.setLatitude(startingLocation.latitude);
        latLocations.add(Double.toString(locLat));
        longLocations.add(Double.toString(locLong));

        cmTimer = (Chronometer) findViewById(R.id.cmTimer);
        btnStart = (Button) findViewById(R.id.btnStart);
        btnStop = (Button) findViewById(R.id.btnStop);
        btnReset = (Button) findViewById(R.id.btnReset);
        distanceView = (TextView) findViewById(R.id.distanceValue);
        curpaceView = (TextView) findViewById(R.id.currentPaceValue);
        curpaceView.setText("00:00");
        distanceView.setText("0.00");
        calView = (TextView) findViewById(R.id.caloriesValue);

        // Get the location manager
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // example setOnChronometerTickListener
        cmTimer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            public void onChronometerTick(Chronometer arg0) {
                if (!resume) {
                    long minutes = ((SystemClock.elapsedRealtime() - cmTimer.getBase())/1000) / 60;
                    long seconds = ((SystemClock.elapsedRealtime() - cmTimer.getBase())/1000) % 60;
                    elapsedTime = SystemClock.elapsedRealtime();

                    if(getLocation() != null){

                        latLocations.add(Double.toString(getLocation().getLatitude()));
                        longLocations.add(Double.toString(getLocation().getLongitude()));

                            if (seconds % 5 == 0 && seconds != 0) {

                            //Add to total distance variable
                            mTotaldistance += calculateDistanceMiles();
                            //Hold values in list so we can calcualte average pace
                            distance_per_second.add(mTotaldistance);
                            //Get new Pace from array of distances
                            mPace = calculatePace(mTotaldistance, minutes, seconds);
                            //get calories(accumlative)
                            if (seconds % 20 == 0) {
                                mCals += (int) calculateCal(distance_per_second.get(distance_per_second.size() - 1));
                                calView.setText(Integer.toString(mCals));
                            }
                            //Update Views
                            double roundDistance = Math.round(mTotaldistance * 100.0) / 100.0;
                            distanceView.setText((Double.toString(roundDistance)));
                            if (!mPace.equals("")) {
                                curpaceView.setText(mPace);
                            }
                        }

                    }

                    String minText;
                    String secText;
                    if (minutes < 10){
                        minText = "0" + Long.toString(minutes);
                    }else{
                        minText = Long.toString(minutes);
                    }
                    if (seconds < 10){
                        secText = "0" + Long.toString(seconds);
                    }else{
                        secText = Long.toString(seconds);
                    }
                    time = minText+":"+secText;
                    mMinutes = minutes;
                    mSeconds = seconds;
                    Log.d(TAG, "onChronometerTick: " + minutes + " : " + seconds);
                } else {
                    long minutes = ((elapsedTime - cmTimer.getBase())/1000) / 60;
                    long seconds = ((elapsedTime - cmTimer.getBase())/1000) % 60;
                    elapsedTime = elapsedTime + 1000;
                    Log.d(TAG, "onChronometerTick: " + minutes + " : " + seconds);

                    String minText;
                    String secText;
                    if (minutes < 10){
                        minText = "0" + Long.toString(minutes);
                    }else{
                        minText = Long.toString(minutes);
                    }
                    if (seconds < 10){
                        secText = "0" + Long.toString(seconds);
                    }else{
                        secText = Long.toString(seconds);
                    }
                    cmTimer.setText(minText+":"+secText);
                    time = minText+":"+secText;
                    mMinutes = minutes;
                    mSeconds = seconds;

                    if(getLocation() != null){

                        latLocations.add(Double.toString(getLocation().getLatitude()));
                        longLocations.add(Double.toString(getLocation().getLongitude()));

                        if (seconds % 5 == 0 && seconds != 0) {
                            //Add to total distance variable
                            mTotaldistance += calculateDistanceMiles();
                            //Hold values in list so we can calcualte average pace
                            distance_per_second.add(calculateDistanceMiles());
                            //Get new Pace from array of distances
                            mPace = calculatePace(mTotaldistance, minutes, seconds);
                            //get calories(accumlative)
                            if (seconds % 20 == 0) {
                                mCals += (int) calculateCal(distance_per_second.get(distance_per_second.size() - 1));
                                calView.setText(Integer.toString(mCals));
                            }
                            //Update Views
                            double roundDistance = Math.round(mTotaldistance * 100.0) / 100.0;
                            distanceView.setText((Double.toString(roundDistance)));
                            if (!mPace.equals("")) {
                                curpaceView.setText(mPace);
                            }
                        }
                    }

                }
            }
        });

    }

    private double calculateDistanceMiles(){
        double hold1 = Double.parseDouble(latLocations.get(latLocations.size() -5));
        double hold2 = Double.parseDouble(longLocations.get(longLocations.size() -5));

        //Calculate Distance
        //double dist = getLocation().distanceTo(start);
        Location.distanceBetween(getLocation().getLatitude(), getLocation().getLongitude(), hold1, hold2, distance_n);
        double dist = Math.abs(distance_n[0]);
        //convert meters to miles
        dist = dist * 0.00062137;

        return dist;
    }

    public String calculatePace(double distance, long min, long sec) {
        if (distance > 0.0) {
            sec = (min * 60) + sec;

            double secPace = sec / distance;
            avgPaceValues.add(secPace);
            int paceMinS = (int) secPace / 60;
            int paceSecS = (int) (secPace % 60);

            if (paceSecS < 10) {
                return paceMinS + ":0" + paceSecS;
            }
            return paceMinS + ":" + paceSecS;
        }
        return "";
    }

    public double calculateCal(double d){
        double hold = 0.0;
        double roundDistance = Math.round(d * 100.0) / 100.0;

        Random rand = new Random();
        int n = rand.nextInt(11) + 6;


        if (roundDistance == hold) {
            return 0;
        } else {
            return (.0175 * n * WEIGHT);
        }
    }

    /**
     * Handle end of run
     * @param view Button view
     */
    public void onEndRun(View view) {
        // End the game and transition to end game activity
        Intent intent = new Intent(this, EndRunActivity.class);
        intent.putStringArrayListExtra("latLocations", latLocations);
        intent.putStringArrayListExtra("longLocations", longLocations);
        double roundDistance = Math.round(mTotaldistance * 100.0) / 100.0;
        intent.putExtra("dist", Double.toString(roundDistance));
        intent.putExtra("pace", mPace);
        intent.putExtra("cals", Integer.toString(mCals));
        intent.putExtra("time", time);
        intent.putExtra("minutes", Long.toString(mMinutes));
        intent.putExtra("seconds", Long.toString(mSeconds));
        startActivity(intent);
        finish();
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btnStart:
                btnStart.setEnabled(false);
                btnStop.setEnabled(true);

                if (!resume) {
                    cmTimer.setBase(SystemClock.elapsedRealtime());
                    cmTimer.start();
                } else {
                    cmTimer.start();
                }
                break;

            case R.id.btnStop:
                btnStart.setEnabled(true);
                btnStop.setEnabled(false);
                cmTimer.stop();
                resume = true;
                btnStart.setText("Resume");
                break;

            case R.id.btnReset:
                cmTimer.stop();
                cmTimer.setText("00:00");
                btnStart.setText(R.string.start_timer);
                btnStart.setEnabled(true);
                resume = false;
                btnStop.setEnabled(false);
                longLocations.clear();
                latLocations.clear();
                mTotaldistance = 0.0;
                distance_per_second.clear();
                mPace = "00:00";
                mCals = 0;
                distanceView.setText("0.0");
                curpaceView.setText("00:00");
                calView.setText("0");
                longLocations.add(Double.toString(startingLocation.longitude));
                latLocations.add(Double.toString(startingLocation.latitude));
                break;
        }
    }

    private void setMargins (View view, int left, int top, int right, int bottom) {
        if (view.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams p = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            p.setMargins(left, top, right, bottom);
            view.requestLayout();
        }
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    private class ActiveListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {

        }

        @Override
        public void onStatusChanged(String s, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    };

    private void registerListeners() {
        unregisterListeners();
    }

    private void unregisterListeners() {
        locationManager.removeUpdates(activeListener);
    }

    /**
     * Called when this application is no longer the foreground application.
     */
    @Override
    protected void onPause() {
        unregisterListeners();
        super.onPause();
    }

    /**
     * Called when this application becomes foreground again.
     */
    @Override
    protected void onResume() {
        super.onResume();
        registerListeners();
    }

    private Location getLocation() {
        Location currentLocation = null;
        // Get the location manager
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // Create a Criteria object
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_HIGH);
        criteria.setAltitudeRequired(true);
        criteria.setBearingRequired(false);
        criteria.setSpeedRequired(false);
        criteria.setCostAllowed(false);

        String bestAvailable = locationManager.getBestProvider(criteria, true);

        if (bestAvailable != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return null;
            }
            locationManager.requestLocationUpdates(bestAvailable, 500, 1, activeListener);
            currentLocation = locationManager.getLastKnownLocation(bestAvailable);
        }
        return currentLocation;
    }
}

