package edu.msu.wojnomat.runningtracker;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This demo shows how GMS Location can be used to check for changes to the users location.  The
 * "My Location" button uses GMS Location to set the blue dot representing the users location.
 * Permission for {@link android.Manifest.permission#ACCESS_FINE_LOCATION} is requested at run
 * time. If the permission has not been granted, the Activity is finished with an error message.
 */
public class MapsActivity extends AppCompatActivity
        implements
        OnMyLocationButtonClickListener,
        OnMyLocationClickListener,
        OnMapReadyCallback,
        ActivityCompat.OnRequestPermissionsResultCallback {

    /**
     * Request code for location permission request.
     *
     * @see #onRequestPermissionsResult(int, String[], int[])
     */
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    /**
     * Flag indicating whether a requested permission has been denied after returning in
     * {@link #onRequestPermissionsResult(int, String[], int[])}.
     */
    private boolean mPermissionDenied = false;

    private GoogleMap mMap;
    private ActiveListener activeListener = new ActiveListener();
    private LocationManager locationManager = null;
    private Location currentLocation = null;
    private ImageView mUserPicture;
    private TextView mdistanceTotalValue;
    private TextView mavgPaceValue;
    private TextView mdistanceTotalLabel;
    private TextView mTotalRunValue;
    private TextView mAvgPaceValue;
    private TextView mCalValue;


    private double mTotalDistance;
    private int mTotalRuns;
    private String mAvgPace = "00:00";
    private int mCals;
    private Long mTotalSeconds = 0l;
    private Long mTotalMinutes = 0l;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_maps);

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    1);
        }

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ViewGroup.LayoutParams params = mapFragment.getView().getLayoutParams();

        mUserPicture = findViewById(R.id.userPicture);
        mdistanceTotalValue = findViewById(R.id.totalDistanceValue);
        mavgPaceValue = findViewById(R.id.avgPaceValue);
        mdistanceTotalLabel = findViewById(R.id.totalDistanceLabel);
        mTotalRunValue = findViewById(R.id.totalRunValue);
        mCalValue = findViewById(R.id.totalCalValue);
        mAvgPaceValue = findViewById(R.id.avgPaceValue);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        int value = sharedPreferences.getInt("runs", 0);

        if (value != 0){
            mTotalDistance = Double.parseDouble(sharedPreferences.getString("dist", ""));
            mTotalDistance = Math.round(mTotalDistance * 100.0) / 100.0;
            mTotalRuns = sharedPreferences.getInt("runs", 0);
            mCals = sharedPreferences.getInt("cals", 0);

            mTotalSeconds = sharedPreferences.getLong("sec", 0);
            mTotalMinutes = sharedPreferences.getLong("min", 0);
            mAvgPace = calculatePace(mTotalDistance, mTotalMinutes, mTotalSeconds);
            if (mAvgPace == ""){
                mAvgPace = "00:00";
            }
            mAvgPaceValue.setText(mAvgPace);

            mCalValue.setText(Integer.toString(mCals));
            mdistanceTotalValue.setText(Double.toString(mTotalDistance));
            mTotalRunValue.setText(Integer.toString(mTotalRuns));
        }


        if (getIntent().getStringExtra("dist") != null) {
            mTotalDistance += Double.parseDouble(getIntent().getStringExtra("dist"));
            mTotalDistance = Math.round(mTotalDistance * 100.0) / 100.0;
            mdistanceTotalValue.setText(Double.toString(mTotalDistance));
            mTotalRuns += Integer.parseInt(getIntent().getStringExtra("totalRuns"));
            mTotalRunValue.setText(Integer.toString(mTotalRuns));
            mCals += Integer.parseInt(getIntent().getStringExtra("cals"));
            mCalValue.setText(Integer.toString(mCals));

            mTotalSeconds += Long.parseLong(getIntent().getStringExtra("sec"));
            mTotalMinutes += Long.parseLong(getIntent().getStringExtra("min"));
            mAvgPace = calculatePace(mTotalDistance, mTotalMinutes, mTotalSeconds);
            if (mAvgPace == ""){
                mAvgPace = "00:00";
            }
            mAvgPaceValue.setText(mAvgPace);
        }

        int width = getScreenWidth();

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {

            if ((width > 480 || width == 480) && width < 1080) {
                //Nexus 4
                mUserPicture.setScaleX(.2f);
                mUserPicture.setScaleY(.2f);
                setMargins(mUserPicture, -100, -120, -50, -60);
                params.height = 300;

            } else if ((width > 1080 || width == 1080) && width < 1200) {
                //Nexus 5
                mUserPicture.setScaleX(.4f);
                mUserPicture.setScaleY(.4f);
                setMargins(mUserPicture, -60, -150, -40, -60);
                params.height = 750;
                setMargins(mdistanceTotalValue, -80, 150, 0, 0);


            } else if ((width > 1200 || width == 1200)) {
                //Nexus 7
                mUserPicture.setScaleX(.6f);
                mUserPicture.setScaleY(.6f);
                setMargins(mUserPicture, -20, -30, 50, 0);
                setMargins(mdistanceTotalValue, -400, 180, 0, 0);
                params.height = 750;
            }
        }

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if ((width > 800 || width == 800) && width < 1794) {
                //Nexus 4

            } else if ((width > 1794 || width == 1794) && width < 1920) {
                //Nexus 5
                mUserPicture.setScaleX(.4f);
                mUserPicture.setScaleY(.4f);
                setMargins(mUserPicture, -60, -150, -40, -60);
                params.height = 300;
                setMargins(mdistanceTotalValue, -600, 100, 0, 0);
                setMargins(mavgPaceValue, 280, -200, 250, 0);
                setMargins(mdistanceTotalLabel, 100, 0, 0, 0);

            } else if ((width > 1920 || width == 1920)) {
                //Nexus 7
            }
        }

        mapFragment.getView().setLayoutParams(params);

        // Get the location manager
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("runs", mTotalRuns);
        editor.putString("dist", Double.toString(mTotalDistance));
        editor.putInt("cals", mCals);
        editor.putLong("min", mTotalMinutes);
        editor.putLong("sec", mTotalSeconds);
        editor.commit();
    }

    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;
        LatLng mylocation;
        if(Build.VERSION.SDK_INT > 22){
            enableMyLocation();
        }
        if (currentLocation != null) {
            mylocation = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        }else{
            currentLocation = getLocation();
            if (currentLocation == null) {
                Toast.makeText(this, "There was a problem getting your location", Toast.LENGTH_SHORT).show();
                Log.i("onMapReady problem", "getLocation returned null");
                Log.i("onMapReady problem", "getLocation returned null");
                Log.i("onMapReady problem", "getLocation returned null");
                return;
            }
            mylocation = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        }
        mMap.addMarker(new MarkerOptions().position(mylocation).snippet("Run will start from this location").title("You are here")).showInfoWindow();
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mylocation,15));

        mMap.setOnMyLocationButtonClickListener(this);
        mMap.setOnMyLocationClickListener(this);
        enableMyLocation();
    }

    /**
     * Handle start of run
     * @param view Button view
     */
    public void onStartRun(View view) {
        if (currentLocation == null) {
            Toast.makeText(this, "You cannot start the run without your location being identified", Toast.LENGTH_LONG).show();
            Log.i("Error", "Tried to start run without location");
            Log.i("Error", "Tried to start run without location");
            Log.i("Error", "Tried to start run without location");
            Log.i("Error", "Tried to start run without location");
            return;
        }
        // End the game and transition to end game activity
        Intent intent = new Intent(this, RunningActivity.class);
        // pass the starting location to running activity
        intent.putExtra("starting_location_latitude", Double.toString(currentLocation.getLatitude()));
        intent.putExtra("starting_location_longitude", Double.toString(currentLocation.getLongitude()));
        startActivity(intent);
    }

    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else if (mMap != null) {
            // Access to the location has been granted to the app.
            mMap.setMyLocationEnabled(true);
        }
    }

    @Override
    public boolean onMyLocationButtonClick() {
        Toast.makeText(this, "MyLocation button clicked", Toast.LENGTH_SHORT).show();
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).
        return false;
    }

    @Override
    public void onMyLocationClick(@NonNull Location location) {
        Toast.makeText(this, "Current location:\n" + location, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode != LOCATION_PERMISSION_REQUEST_CODE) {
            return;
        }

        if (PermissionUtils.isPermissionGranted(permissions, grantResults,
                Manifest.permission.ACCESS_FINE_LOCATION)) {
            // Enable the my location layer if the permission has been granted.
            enableMyLocation();
        } else {
            // Display the missing permission error dialog when the fragments resume.
            mPermissionDenied = true;
        }
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        if (mPermissionDenied) {
            // Permission was not granted, display error dialog.
            showMissingPermissionError();
            mPermissionDenied = false;
        }
    }

    /**
     * Displays a dialog with error message explaining that the location permission is missing.
     */
    private void showMissingPermissionError() {
        PermissionUtils.PermissionDeniedDialog
                .newInstance(true).show(getSupportFragmentManager(), "dialog");
    }

    private void setMargins (View view, int left, int top, int right, int bottom) {
        if (view.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams p = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            p.setMargins(left, top, right, bottom);
            view.requestLayout();
        }
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    private class ActiveListener implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {

        }

        @Override
        public void onStatusChanged(String s, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    };

    private void registerListeners() {
        unregisterListeners();
    }

    private void unregisterListeners() {
        locationManager.removeUpdates(activeListener);
    }

    /**
     * Called when this application is no longer the foreground application.
     */
    @Override
    protected void onPause() {
        unregisterListeners();
        super.onPause();
    }

    /**
     * Called when this application becomes foreground again.
     */
    @Override
    protected void onResume() {
        super.onResume();
        registerListeners();
    }

    private Location getLocation() {
        Location currentLocation = null;
        // Get the location manager
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // Create a Criteria object
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_HIGH);
        criteria.setAltitudeRequired(true);
        criteria.setBearingRequired(false);
        criteria.setSpeedRequired(false);
        criteria.setCostAllowed(false);

        String bestAvailable = locationManager.getBestProvider(criteria, true);

        if (bestAvailable != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return null;
            }
            locationManager.requestLocationUpdates(bestAvailable, 500, 1, activeListener);
            currentLocation = locationManager.getLastKnownLocation(bestAvailable);
        }
        return currentLocation;
    }

    public String calculatePace(double distance, long min, long sec) {
        if (distance > 0.0) {
            sec = (min * 60) + sec;

            double secPace = sec / distance;
            int paceMinS = (int) secPace / 60;
            int paceSecS = (int) (secPace % 60);

            if (paceSecS < 10) {
                return paceMinS + ":0" + paceSecS;
            }
            return paceMinS + ":" + paceSecS;
        }
        return "";
    }

}